﻿
// Lab05_EditCtrlView.cpp: CLab05EditCtrlView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "Lab05_EditCtrl.h"
#endif

#include "Lab05_EditCtrlDoc.h"
#include "Lab05_EditCtrlView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLab05EditCtrlView

IMPLEMENT_DYNCREATE(CLab05EditCtrlView, CFormView)

BEGIN_MESSAGE_MAP(CLab05EditCtrlView, CFormView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CFormView::OnFilePrintPreview)
	ON_EN_CHANGE(IDC_MYEDIT1, &CLab05EditCtrlView::OnEnChangeMyedit1)
	ON_EN_CHANGE(IDC_MYEDIT2, &CLab05EditCtrlView::OnEnChangeMyedit2)
	ON_EN_MAXTEXT(IDC_MYEDIT1, &CLab05EditCtrlView::OnEnMaxtextMyedit1)
	ON_BN_CLICKED(IDC_BUTTON1, &CLab05EditCtrlView::OnBnClickedButton1)
END_MESSAGE_MAP()

// CLab05EditCtrlView 생성/소멸

CLab05EditCtrlView::CLab05EditCtrlView() noexcept
	: CFormView(IDD_LAB05_EDITCTRL_FORM)
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CLab05EditCtrlView::~CLab05EditCtrlView()
{
}

void CLab05EditCtrlView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MYEDIT1, m_edit1);
	DDX_Control(pDX, IDC_MYEDIT2, m_edit2);
	DDX_Control(pDX, IDC_BUTTON1, m_button);
}

BOOL CLab05EditCtrlView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CFormView::PreCreateWindow(cs);
}

void CLab05EditCtrlView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	m_edit1.SetLimitText(30); // 최대 30글자까지 입력 가능

}


// CLab05EditCtrlView 인쇄

BOOL CLab05EditCtrlView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CLab05EditCtrlView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CLab05EditCtrlView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}

void CLab05EditCtrlView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: 여기에 사용자 지정 인쇄 코드를 추가합니다.
}


// CLab05EditCtrlView 진단

#ifdef _DEBUG
void CLab05EditCtrlView::AssertValid() const
{
	CFormView::AssertValid();
}

void CLab05EditCtrlView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CLab05EditCtrlDoc* CLab05EditCtrlView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLab05EditCtrlDoc)));
	return (CLab05EditCtrlDoc*)m_pDocument;
}
#endif //_DEBUG


// CLab05EditCtrlView 메시지 처리기


void CLab05EditCtrlView::OnBnClickedButton1()
{
	CString text; // text 변수 CString으로 선언
	m_edit1.GetWindowText(text); // 첫 번째로 입력된 위쪽 Editctrl box의 text 문자열 받아오기
	list = list + text + _T("\r\n"); // 원래 text 문자열 + 입력받은 text 문자열 + 줄바꿈한 결과를 list에 저장
	m_edit2.SetWindowTextW(list); // 아래쪽 Editctrl box에 list 추가
	m_edit1.SetSel(0, -1); // 입력한 줄의 전체 선택
	m_edit1.Clear(); // 입력한 내용 지우기
	int Length = m_edit2.GetWindowTextLengthW(); // 아래쪽 Editctrl box의 줄을 Length 변수에 저장
	m_edit2.SetSel(Length, Length - 1); // 아래쪽 Editctrl box의 마지막 줄로 이동
}


void CLab05EditCtrlView::OnEnChangeMyedit1()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CLab05EditCtrlView::OnEnChangeMyedit2()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CFormView::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CLab05EditCtrlView::OnEnMaxtextMyedit1()
{
	MessageBox(_T("최대 길이 도달!!"), _T("오류"), MB_ICONERROR); // 최대 글자수 초과하였을 때 출력되는 메세지
}